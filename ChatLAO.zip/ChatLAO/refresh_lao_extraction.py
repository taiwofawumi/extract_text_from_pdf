# Databricks notebook source
# MAGIC %sh
# MAGIC apt-get clean
# MAGIC rm -rf /var/lib/apt/lists/*
# MAGIC apt-get update
# MAGIC apt-get install -y poppler-utils tesseract-ocr libtesseract-dev --fix-missing
# MAGIC apt-get install -y libreoffice --fix-missing

# COMMAND ----------

# MAGIC %pip install -q pdf2image pypdf pytesseract pillow opencv-python 

# COMMAND ----------

import os
import re
import io
import json
import base64
import tempfile
from typing import Optional, List, Dict
from pdf2image import convert_from_bytes
import pytesseract
import cv2
import numpy as np
import subprocess
from PIL import Image
from bs4 import BeautifulSoup
from pypdf import PdfReader
from datetime import datetime
from delta.tables import DeltaTable
from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException
import pyspark.sql.functions as F
import logging
from utils.configs import *
import traceback
import warnings

# initiate log_messages list
log_messages = []

# Suppress all warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# initiate spark
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

def normalize_path(path: str) -> str:
    if path.startswith("dbfs:/"):
        return path.replace("dbfs:/", "/dbfs/")
    return path

@F.udf(returnType=StringType())
def normalize_path_udf(path: str) -> str:
    if path.startswith("dbfs:/"):
        return path.replace("dbfs:/", "/dbfs/")
    return path

def read_file_bytes(path: str) -> bytes:
    local_path = normalize_path(path)
    with open(local_path, "rb") as f:
        return f.read()

def make_pages(page_texts: List[str]) -> List[Dict[str, str]]:
    """
    Convert list of page texts into canonical paginated structure.
    Page numbers are 1-based.
    """
    return [
        {"PageNumber": i + 1, "PageText": text.strip()}
        for i, text in enumerate(page_texts)
    ]

def preprocess_pil_image_for_ocr(pil_img: Image.Image) -> Image.Image:
    """Common preprocessing: grayscale, adaptive threshold, optional denoise."""
    # Convert to OpenCV
    img = np.array(pil_img)
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    # Resize if extremely small — keep scale reasonable
    h, w = img.shape[:2]
    if max(h, w) < 1000:
        scale = 1000.0 / max(h, w)
        img = cv2.resize(img, (int(w*scale), int(h*scale)), interpolation=cv2.INTER_LINEAR)
    # Adaptive threshold
    img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY, 31, 10)
    # Optionally: median blur to reduce noise
    img = cv2.medianBlur(img, 3)
    return Image.fromarray(img)

def extract_pdf_pages_ocr(pdf_path: str, lang: str = "eng") -> str:
    """
    OCR-only PDF text extraction.
    """
    pdf_bytes = read_file_bytes(pdf_path)

    try:
        page_images = convert_from_bytes(pdf_bytes, dpi=300)
    except Exception as e:
        raise RuntimeError(f"PDF → image conversion failed: {pdf_path}") from e

    page_texts = []

    for page in page_images: 
        processed = preprocess_pil_image_for_ocr(page)

        text = pytesseract.image_to_string(
            processed,
            lang=lang,
            config="--oem 1 --psm 3"  # LSTM + auto layout
        )

        page_texts.append(text)

    return make_pages(page_texts)

def office_to_html(doc_path: str) -> str:
    doc_path = normalize_path(doc_path)
    tmpdir = tempfile.mkdtemp()

    subprocess.run(
        [
            "soffice",
            "--headless",
            "--convert-to", "html",
            "--outdir", tmpdir,
            doc_path
        ],
        check=True
    )

    base = os.path.splitext(os.path.basename(doc_path))[0]
    html_path = os.path.join(tmpdir, base + ".html")

    if not os.path.exists(html_path):
        raise RuntimeError("LibreOffice HTML conversion failed")

    return html_path

def extract_office_pages(path: str):
    html_path = office_to_html(path)

    with open(html_path, "r", encoding="utf-8", errors="ignore") as f:
        soup = BeautifulSoup(f, "html.parser")

    for tag in soup(["script", "style"]):
        tag.decompose()

    text_blocks = []

    # LibreOffice often inserts page breaks
    page_breaks = soup.find_all("div", style=lambda s: s and "page-break" in s)

    if page_breaks:
        for pb in page_breaks:
            text_blocks.append(pb.get_text(separator="\n", strip=True))
    else:
        # Fallback: paragraph grouping
        paragraphs = [p.get_text(strip=True) for p in soup.find_all("p")]
        text_blocks = ["\n".join(paragraphs)]

    return make_pages(text_blocks)

def extract_document_pages(path: str) -> str:
    """
    Extract text from documents.
    PDFs are ALWAYS OCR-processed.
    """
    path_local = normalize_path(path)
    ext = os.path.splitext(path_local)[1].lower()

    if ext == ".pdf":
        return extract_pdf_pages_ocr(path_local)

    elif ext in (".docx", ".rtf"):
        return extract_office_pages(path_local)

    else:
        raise ValueError(f"Unsupported file type: {ext}")

def process_documents_to_dataframe(file_paths: list[str]):
    rows = []

    for file_path in file_paths:
        local_path = normalize_path(file_path)

        if not os.path.exists(local_path):
            raise FileNotFoundError(f"File not found: {local_path}")

        text = extract_document_pages(file_path)

        row = {
            "ExtractedText": text,
            "DalkFilePath": file_path
        }

        rows.append(row)

    if not rows:
        raise ValueError("No documents were processed")

    return spark.createDataFrame(rows, document_schema)

def update_extraction_archive(df, table_path):
    if DeltaTable.isDeltaTable(spark, table_path):
        # Check if table exists
        delta_table = DeltaTable.forPath(spark, table_path)
        
        # Register temp view
        df.createOrReplaceTempView("df_load_status")
        
        # Get column names dynamically
        cols = df.columns
        update_set = ", ".join([f"target.{c} = source.{c}" for c in cols])
        insert_cols = ", ".join(cols)
        insert_vals = ", ".join([f"source.{c}" for c in cols])
        
        # merge into
        merge_query = f"""
        MERGE INTO delta.`{table_path}` AS target
        USING df_load_status AS source
        ON target.DalkFilePath = source.DalkFilePath
        WHEN MATCHED THEN 
            UPDATE SET {update_set}
        WHEN NOT MATCHED THEN 
            INSERT ({insert_cols}) VALUES ({insert_vals})
        """
        spark.sql(merge_query)
        log.info(f"MERGE completed into {table_path}")
        
    else:
        # First time loads
        df.write.format("delta").mode("append").save(table_path)
        log.info(f"Table {table_path} did not exist. Created and loaded first batch.")

def write_json_partition(rows):
    for row in rows:
        json_path = "/dbfs" + row.JsonFilePath

        # Ensure parent directory exists
        os.makedirs(os.path.dirname(json_path), exist_ok=True)

        # Write JSON
        record = [row.asDict(recursive=True)]
        with open(json_path, "w") as f:
            json.dump(record, f, indent=2)


# COMMAND ----------

def main():
    try:
        # Load LAO metadata
        log.info('Loading LAO metadata..')
        df_metadata = (spark.read.format("json").load(f"dbfs:{metadata_json_lines_path}")
                       .withColumn("DalkFilePath", normalize_path_udf("DalkFilePath")))

        # filter files already processed based on filehash  
        log.info('Getting new approved LAOs yet to be extracted..')      
        if DeltaTable.isDeltaTable(spark, extraction_archive_path):
            df_extracted = spark.read.format('delta').load(extraction_archive_path)
            df_new = df_metadata.join(df_extracted, 'FileHash', 'left_anti')
        else:
            df_new = df_metadata

        if df_new.isEmpty():
            dbutils.notebook.exit("No new files to be extracted")

        log.info(f"Found {df_new.count()} new/updated LAO files to be extracted. Extracting files..")

        # Extract text from files
        new_file_paths = [row.DalkFilePath for row in df_new.select("DalkFilePath").collect()]
        df_extraction = process_documents_to_dataframe(file_paths=new_file_paths)
        df_extraction = df_extraction.persist()
        df_extraction = (df_extraction
                        .withColumn('Pages', F.size(F.col('ExtractedText')))
                        .withColumn("ExtractionTime", F.lit(datetime.utcnow().isoformat())))
        # df_extraction.display()

        # Merge extractions back into metadata
        df_extraction_final = (df_metadata.join(df_extraction, 'DalkFilePath', 'inner'))
        # df_extraction_final.display()
        
        # archive extractions
        log.info("Updating archive with new/updated extractions")
        update_extraction_archive(df_extraction_final, extraction_archive_path)

        # # save all extractions as a single json
        # records = [row.asDict(recursive=True) for row in df_extraction_final.collect()]
        # with open("/dbfs" + extraction_json_path, "w") as f:
        #     json.dump(records, f, indent=2)

        # save individual json files
        log.info("Saving extractions as json files")
        df_extraction_final.select(text_json_cols).foreachPartition(write_json_partition)
        
        df_extraction.unpersist()

        log.info("Run complete")
    
    except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while running main: {e} \n{tb}")

if __name__ == "__main__":
    main()

# COMMAND ----------

