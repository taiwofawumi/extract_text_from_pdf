# Databricks notebook source
import json
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from utils.configs import *
from glob import glob
import hashlib
import traceback

# COMMAND ----------

# initiate spark
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# MAGIC %sql
# MAGIC USE brhistory_tcis

# COMMAND ----------

def normalize_path(path: str) -> str:
    if path.startswith("dbfs:/"):
        return path.replace("dbfs:/", "/dbfs/")
    return path

@F.udf(returnType=StringType())
def normalize_path_udf(path: str) -> str:
    if path.startswith("dbfs:/"):
        return path.replace("dbfs:/", "/dbfs/")
    return path

def trim_join_cols(df, cols):
    for c in cols:
        df = df.withColumn(c, F.trim(F.col(c)))
    return df

# def get_lao_from_landing():
#     log.info('Loading LAO files from landing..')
#     file_paths = glob(os.path.join(dalk_pdf_base_dir, '**', '*.pdf'), recursive=True)
#     df = spark.createDataFrame([(p,) for p in file_paths
#                         if '/approval and rescind letters and emails/' not in p.lower()
#                         and '/approval letters/' not in p.lower()
#                         and '/language access/' not in p.lower()], ['DalkFilePath'])
#     # df = df.limit(20) # limit for testing
#     df_all_files = (df.withColumn("CourtType", F.regexp_extract("DalkFilePath", r"/LAO/([^/]+)/", 1))
#                 .withColumn("CourtCode", F.regexp_extract("DalkFilePath", r"/LAO/[^/]+/([^/\\s-]+)", 1))
#                 .withColumn("OrderNumber", F.regexp_extract("DalkFilePath", r"/LAOs/(?:.*?[\s-]+)?((?:[0-9]{4})(?:-[0-9]{1,2}[A-Z]?)?)", 1)))
#     df_all_files = trim_join_cols(df_all_files, join_cols)
#     df_all_files = df_all_files.withColumn("CourtType", F.regexp_replace(F.col("CourtType"), "UTC", "Unified Trial Court"))
#     return df_all_files

def get_lao_from_landing():
    log.info('Loading LAO files from landing..')
    df = (spark.read.format("binaryFile")
          .option("recursiveFileLookup", "true")
          .load(landing_base_dir)
          .filter(~F.lower(F.col("path")).contains("approval and rescind letters and emails"))
          .filter(~F.lower(F.col("path")).contains("approval letters"))
          .filter(~F.lower(F.col("path")).contains("language access"))
          # .filter(F.col("modificationTime") > F.to_timestamp(F.lit(LastRunTime)))
          .select(F.col("path").alias("DalkFilePath"),
                  F.date_format(F.col("modificationTime"), "yyyy-MM-dd HH:mm:ss").alias("DalkLastModified")))
    
    df_all_files = (df.withColumn("CourtType", F.regexp_extract("DalkFilePath", r"/LAO/([^/]+)/", 1))
                .withColumn("CourtCode", F.regexp_extract("DalkFilePath", r"/LAO/[^/]+/([^/\\s-]+)", 1))
                .withColumn("OrderNumber", F.regexp_extract("DalkFilePath", r"/LAOs/(?:.*?[\s-]+)?((?:[0-9]{4})(?:-[0-9]{1,2}[A-Z]?)?)", 1))
                .withColumn("DalkFilePath", normalize_path_udf(F.col("DalkFilePath"))))
    df_all_files = trim_join_cols(df_all_files, join_cols)
    df_all_files = df_all_files.withColumn("CourtType", F.regexp_replace(F.col("CourtType"), "UTC", "Unified Trial Court"))

    return df_all_files

def get_tcis_lao_metadata():
    log.info("Getting curated metadata..")
    df_full_metadata = spark.sql(get_metadata_query)

    # apply filters
    log.info("Applying filters for LAOs with approved status..")
    df_metadata = (df_full_metadata.select(metadata_cols)
                .withColumn('CourtCounty', F.initcap(F.col('CourtCounty')))
                .filter("TRIM(LaoStatus) = 'Approved'"))
    df_metadata = trim_join_cols(df_metadata, join_cols).filter(df_metadata.CourtType.isin(court_type_list))

    return df_metadata

@F.udf(returnType=StringType())
def compute_file_sha256(file_path: str) -> str:
    file_path_local = normalize_path(file_path)
    sha256 = hashlib.sha256()
    with open(file_path_local, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()

# COMMAND ----------

def main():
    try:
        # load lao files from landing
        df_all_files = get_lao_from_landing()
        log.info(f"Total Number of LAO files in landing: {df_all_files.count()}")

        # get curated metadata        
        df_metadata = get_tcis_lao_metadata()
        log.info(f"Found {df_metadata.count()} currently approved LAO metadata records")
        # df_metadata.display()

        # match LAO files from landing to TCIS metadata
        log.info("Matching LAO files from landing to TCIS metadata")
        df_matched = df_metadata.join(df_all_files, on=join_cols , how='inner')
        log.info(f"Number of TCIS approved metadata records matched: {df_matched.select(join_cols).distinct().count()}")
        log.info(f"Number of approved LAO files matched to TCIS metadata: {df_matched.count()}")

        if load_mode == "incremental":
            # detect file changes
            log.info("Detecting file changes..")
            df_archive = spark.read.format("delta").load(metadata_archive_path).select("DalkFilePath", 
                                                                                       F.col("DalkLastModified").alias("ArchiveLastModified"), 
                                                                                       "FileHash")
            df_joined = df_matched.join(df_archive, on="DalkFilePath", how="left")
            df_metadata_flagged = df_joined.withColumn("NeedsRehash", F.when((F.col("ArchiveLastModified").isNull()) | 
                                                                             (F.col("DalkLastModified") != F.col("ArchiveLastModified")),
                                                                             F.lit(True)).otherwise(F.lit(False)))
            
            log.info(f"{df_metadata_flagged.filter(F.col('NeedsRehash')).count()} Files needs rehash..")

            # rehash
            df_rehash = df_metadata_flagged.filter(F.col("NeedsRehash"))
            df_no_rehash = df_metadata_flagged.filter(~F.col("NeedsRehash"))
            df_rehash = df_rehash.withColumn("FileHash", compute_file_sha256(F.col("DalkFilePath")))

            # enrich metadata with JsonFilePath and NetworkFilePath
            df_metadata_final = (df_no_rehash.unionByName(df_rehash)
                                 .withColumn('JsonFilePath', F.regexp_replace(
                                                        F.regexp_replace(F.col("DalkFilePath"), dalk_pdf_base_dir, dalk_json_base_dir),
                                                            r'(?i)\.pdf$', '.json'))
                                .withColumn('NetworkFilePath', F.regexp_replace( 
                                        F.regexp_replace(F.col("DalkFilePath"), dalk_pdf_base_dir, network_base_dir),
                                        ' ', '%20'))
                                 .drop("ArchiveLastModified", "NeedsRehash"))
        else: # full load
            # enrich metadata with FileHash, JsonFilePath and NetworkFilePath
            df_metadata_final = (df_matched.withColumn('JsonFilePath', F.regexp_replace(
                                                        F.regexp_replace(F.col("DalkFilePath"), dalk_pdf_base_dir, dalk_json_base_dir),
                                                            r'(?i)\.pdf$', '.json'))
                                .withColumn('NetworkFilePath', F.regexp_replace( 
                                        F.regexp_replace(F.col("DalkFilePath"), dalk_pdf_base_dir, network_base_dir),
                                        ' ', '%20'))
                                .withColumn("FileHash", compute_file_sha256(F.col("DalkFilePath")))
                                )

        df_metadata_final = df_metadata_final.persist()

        # convert nulls to empty strings
        df_metadata_final = df_metadata_final.select([F.coalesce(F.col(c).cast("string"), F.lit("")).alias(c)
                    for c in df_metadata_final.columns
                ])

        # archive metadata    
        log.info("Archiving metadata..")
        df_metadata_final.write.format('delta').mode('overwrite').option('overwriteSchema', True).save(metadata_archive_path)

        # store metadata as JSON blob for copilot studio    
        log.info("Saving metadata as a Json file..")
        # dbutils.fs.mkdirs(f"dbfs:{metadata_base_dir}")

        # JSON file
        records = [row.asDict(recursive=True) for row in df_metadata_final.select(metadata_json_cols).collect()]        
        payload = {
            "data": records,
            "count": len(records)
        }
        with open("/dbfs" + metadata_json_path, "w") as f:
            json.dump(payload, f, indent=2)

        # JSON line-by-line
        df_metadata_final.coalesce(1).write.mode("overwrite").json(metadata_temp_path)
        files = dbutils.fs.ls(metadata_temp_path)
        json_file = [f.path for f in files if f.name.endswith(".json")][0]
        dbutils.fs.mv(json_file, metadata_json_lines_path)

        # store metadata as HTML blob for copilot studio
        html = df_metadata_final.toPandas().to_html(index=False)
        dbutils.fs.put(metadata_html_path, html, overwrite=True)

        df_metadata_final.unpersist()
        log.info("Run complete")
    
    except Exception as e:
        tb = traceback.format_exc() # enable error traceback
        raise Exception(f"Error occurred while running main: {e} \n{tb}")


if __name__ == "__main__":
    main()

# COMMAND ----------

