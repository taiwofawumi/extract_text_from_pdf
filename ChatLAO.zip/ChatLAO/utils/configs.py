import os
import time
from pyspark.sql.types import StringType, IntegerType, FloatType, ArrayType, StructType, StructField, DateType, BooleanType
import logging

# configure logging
def get_logger(name="chatlao"):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s-%(name)s-%(levelname)s-%(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

log = get_logger()
env = os.getenv("ENV") # current environment e.g., sbx, dev, staging, prod
load_mode = 'incremental' # incremental OR Full

network_base_dir = "file://hoj-fs-scao.court.mi.local/all/FILES/TCS/Court and County Files 802"
landing_base_dir = "/mnt/landing/LAO"
dalk_pdf_base_dir = "/dbfs/mnt/landing/LAO"
dalk_json_base_dir = "/mnt/laointerface/LAO/files/json"

metadata_base_dir = "/mnt/laointerface/LAO/metadata"
metadata_archive_path = f"{metadata_base_dir}/data"
metadata_json_path = f"{metadata_base_dir}/json/metadata.json"
metadata_json_lines_path = f"{metadata_base_dir}/json/metadata_json_lines.json"
metadata_html_path = f"{metadata_base_dir}/html/metadata.html"
metadata_temp_path = f"{metadata_base_dir}/temp/_tmp_metadata"

extraction_archive_path = "/mnt/laointerface/LAO/extraction/data"
extraction_json_path = "/mnt/laointerface/LAO/extraction/json"

court_type_list = ["Circuit", "District", "Probate", "Municipal", "Unified Trial Court"]
metadata_cols = ['OrderNumber', 'LaoSubject', 'LaoStatus', 'LaoStatusDate', 
                 'LaoType', 'LaoTypeDescription', 'CourtType', 'CourtCode', 
                 'CourtCounty', 'CourtName', 'Region']
metadata_json_cols = ['OrderNumber', 'LaoSubject', 'LaoTypeDescription', 'CourtType', 'CourtCode', 
                 'CourtCounty', 'CourtName', 'Region', 'JsonFilePath']
join_cols = ['CourtType', 'CourtCode', 'OrderNumber'] 
text_json_cols = ['CourtType', 'CourtCode', 'OrderNumber', 'CourtCounty', 'CourtName', 'LaoStatus', 
                  'LaoStatusDate', 'LaoSubject', 'LaoType', 'LaoTypeDescription', 'Region', 
                  'ExtractedText', 'Pages', 'ExtractionTime', 'JsonFilePath', 'NetworkFilePath']

page_schema = StructType([
    StructField("PageNumber", IntegerType(), False),
    StructField("PageText", StringType(), True)
])

document_schema = StructType([
    StructField("DalkFilePath", StringType(), False),
    StructField("ExtractedText", ArrayType(page_schema), False)
    ])

get_metadata_query = """
                    SELECT 
                        LAO.tri_localadministrativeorderid AS Id,
                        orgsubtype.tri_name AS CourtType,
                        account.tri_organizationcodeshort AS CourtCode, 
                        account.tri_countystring AS CourtCounty,
                        account.tri_organizationname AS CourtName,  
                        LAO.tri_ordernumber AS OrderNumber,    
                        laotype.tri_name AS LaoType,
                        laotype.tri_meaning AS LaoTypeDescription,
                        LAO.tri_subject AS LaoSubject,
                        laostatusvalues.tri_name AS LaoStatus,
                        CAST(LAO.tri_statusdate AS STRING) AS LaoStatusDate,
                        LAO.tri_statusid AS StatusId,
                        LAO.tri_notes AS LaoNotes,
                        orgtype.tri_name AS OrganizationType,
                        account.tri_organizationcode AS CourtFullCode,  
                        CAST(LAO.tri_dateonorder AS STRING) AS DateOnOrder,
                        CAST(LAO.tri_receiveddate AS STRING) AS ReceivedDate,
                        CAST(LAO.tri_expiredate AS STRING) AS ExpiredDate,
                        LAO.tri_recommended AS Recommended,
                        CAST(LAO.tri_region AS STRING) AS Region,
                        CAST(LAO.tri_regionalapprovaldate AS STRING) AS RegionalApprovalDate,
                        LAO.tri_required AS Required,
                        CAST(LAO.tri_resubmittedasdate AS STRING) AS ResubmittedDate,
                        CAST(LAO.tri_reviewdate AS STRING) AS ReviewDate,
                        CAST(LAO.tri_scaoapprovaldate AS STRING) AS SCAOApprovalDate,
                        LAO.tri_submittedasnumber AS SubmittedAsNumber,
                        laoletter.tri_localadministrativeorderletterid AS LetterId,
                        laoletter.tri_name AS LetterName,
                        CAST(LAO.createdon AS STRING) AS CreatedOn,
                        createdby.fullname AS CreatedByFullName,
                        createdby.identityid AS CreatedByIdentityId,
                        createdby.internalemailaddress AS CreatedByEmail,
                        CAST(LAO.jis_creationdateandtime AS STRING) AS JisCreationDateTime,
                        jis_creatinguser.fullname AS JisCreatingUserFullName,
                        jis_creatinguser.identityid AS JisCreatingUserIdentityId,
                        jis_creatinguser.internalemailaddress AS JisCreatingUserEmail,
                        CAST(LAO.modifiedon AS STRING) AS ModifiedOn,
                        modifiedby.fullname AS ModifiedByFullName,
                        modifiedby.identityid AS ModifiedByIdentityId,
                        modifiedby.internalemailaddress AS ModifiedByEmail,
                        CAST(LAO.jis_modificationdateandtime AS STRING) AS ModificationDateTime,
                        jis_modifyinguser.fullname AS JisModifyingUserFullName,
                        jis_modifyinguser.identityid AS JisModifyingUserIdentityId,
                        jis_modifyinguser.internalemailaddress AS JisModifyingUserEmail,
                        owninguser.fullname AS OwningUserFullName,
                        owninguser.identityid AS OwningUserIdentityId,
                        owninguser.internalemailaddress AS OwningUserEmail,
                        appointedperson.fullname AS AppointedPersonFullName,
                        appointedperson.emailaddress1 AS AppointedPersonEmail,
                        approvedby.fullname AS ApprovedByFullName,
                        approvedby.emailaddress1 AS ApprovedByEmail

                    FROM tri_localadministrativeorder LAO

                    LEFT JOIN systemuser createdby
                        ON LAO.createdby = createdby.systemuserid
                    LEFT JOIN systemuser createdonbehalfby
                        ON LAO.createdonbehalfby = createdonbehalfby.systemuserid
                    LEFT JOIN systemuser jis_creatinguser
                        ON LAO.jis_creatinguser = jis_creatinguser.systemuserid
                    LEFT JOIN systemuser jis_modifyinguser
                        ON LAO.jis_modifyinguser = jis_modifyinguser.systemuserid
                    LEFT JOIN systemuser modifiedby
                        ON LAO.modifiedby = modifiedby.systemuserid
                    LEFT JOIN systemuser modifiedonbehalfby
                        ON LAO.modifiedonbehalfby = modifiedonbehalfby.systemuserid
                    LEFT JOIN systemuser owninguser
                        ON LAO.owninguser = owninguser.systemuserid

                    LEFT JOIN tri_localadministrativeorderletter laoletter
                        ON LAO.jis_currentstatusletter = laoletter.tri_localadministrativeorderletterid
                        
                    -- LEFT JOIN businessunit
                    --     ON LAO.owningbusinessunit = businessunit.businessunitid

                    -- LEFT JOIN team
                    --     ON LAO.owningteam = team.teamid

                    LEFT JOIN contact appointedperson
                        ON LAO.tri_appointedpersonid = appointedperson.contactid
                    LEFT JOIN contact approvedby
                        ON LAO.tri_approvedbyid = approvedby.contactid

                    LEFT JOIN tri_jointlaogroup
                        ON LAO.tri_autonumberid = tri_jointlaogroup.tri_jointlaogroupid

                    LEFT JOIN account
                        ON LAO.tri_courtid = account.accountid

                    LEFT JOIN tri_jointlao
                        ON LAO.tri_jointnumberid = tri_jointlao.tri_jointlaoid

                    LEFT JOIN tri_localadministrativeordertype laotype
                        ON LAO.tri_laotypeid = laotype.tri_localadministrativeordertypeid

                    LEFT JOIN tri_localadminstatusvalues laostatusvalues
                        ON LAO.tri_statusid = laostatusvalues.tri_localadminstatusvaluesid

                    LEFT JOIN tri_organizationtype orgtype
                        ON account.tri_organizationtype = orgtype.tri_organizationtypeid

                    LEFT JOIN tri_organizationsubtype orgsubtype
                        ON account.tri_organizationsubtypeid = orgsubtype.tri_organizationsubtypeid
                """